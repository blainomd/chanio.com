// chanio content script
// Injects the persistent bottom bar using Shadow DOM for style isolation

(function () {
  // Avoid double injection
  if (document.getElementById("chanio-root")) return;

  const STORIES = [
    "Your AI remembers this page.",
    "One discovery a day.",
    "Making the web surfable and memorable.",
    "Save what matters. Surf what you haven't seen.",
    "The web is bigger than your feed.",
    "Every page is a thread worth pulling."
  ];

  let storyIndex = 0;
  let chatOpen = false;
  let chatHistory = [];
  let isRecording = false;
  let recognition = null;

  // Create the Shadow DOM host
  const host = document.createElement("div");
  host.id = "chanio-root";
  host.style.cssText = [
    "position: fixed",
    "bottom: 0",
    "left: 0",
    "right: 0",
    "height: 44px",
    "z-index: 2147483647",
    "pointer-events: none"
  ].join(";");
  document.documentElement.appendChild(host);

  const shadow = host.attachShadow({ mode: "closed" });

  // ── Styles ──────────────────────────────────────────────────────────────────
  const style = document.createElement("style");
  style.textContent = `
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }

    #chanio-bar {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 44px;
      background: #0A1420;
      border-top: 1px solid #1a3040;
      display: flex;
      align-items: center;
      padding: 0 12px;
      gap: 8px;
      pointer-events: all;
      user-select: none;
    }

    .chanio-wordmark {
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      color: #0D7377;
      text-transform: lowercase;
      flex-shrink: 0;
      cursor: default;
      text-decoration: none;
    }

    .chanio-divider {
      width: 1px;
      height: 20px;
      background: #1a3040;
      flex-shrink: 0;
    }

    .chanio-story {
      flex: 1;
      font-size: 11px;
      color: #6b8fa8;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.4s ease;
      cursor: default;
      min-width: 0;
    }

    .chanio-story.fade {
      opacity: 0;
    }

    .chanio-btn {
      display: flex;
      align-items: center;
      gap: 5px;
      background: none;
      border: none;
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 4px;
      color: #6b8fa8;
      font-size: 11px;
      font-weight: 500;
      transition: background 0.15s, color 0.15s;
      flex-shrink: 0;
      line-height: 1;
    }

    .chanio-btn:hover {
      background: #0d2030;
      color: #0D7377;
    }

    .chanio-btn:active {
      background: #0a2535;
    }

    .chanio-btn svg {
      width: 14px;
      height: 14px;
      flex-shrink: 0;
    }

    .chanio-surf-btn {
      color: #0D7377;
      border: 1px solid #0D7377;
      font-weight: 600;
    }

    .chanio-surf-btn:hover {
      background: #0D7377;
      color: #0A1420;
    }

    .chanio-mic-btn.recording {
      color: #e05050;
      animation: pulse 1s ease-in-out infinite;
    }

    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.5; }
    }

    .chanio-legal {
      font-size: 9px;
      color: #253a4a;
      flex-shrink: 0;
      white-space: nowrap;
    }

    .chanio-save-flash {
      position: absolute;
      bottom: 50px;
      right: 12px;
      background: #0D7377;
      color: #0A1420;
      font-size: 11px;
      font-weight: 600;
      padding: 6px 12px;
      border-radius: 4px;
      pointer-events: none;
      opacity: 0;
      transform: translateY(4px);
      transition: opacity 0.2s ease, transform 0.2s ease;
      white-space: nowrap;
    }

    .chanio-save-flash.visible {
      opacity: 1;
      transform: translateY(0);
    }

    /* ── Chat panel ─────────────────────────────────────────────────────────── */
    #chanio-chat {
      position: absolute;
      bottom: 44px;
      left: 0;
      right: 0;
      background: #0A1420;
      border-top: 1px solid #1a3040;
      display: flex;
      flex-direction: column;
      pointer-events: all;
      transform: translateY(100%);
      transition: transform 0.25s ease;
      height: 320px;
      max-height: calc(100vh - 60px);
    }

    #chanio-chat.open {
      transform: translateY(0);
    }

    .chanio-chat-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 14px;
      border-bottom: 1px solid #1a3040;
      flex-shrink: 0;
    }

    .chanio-chat-title {
      font-size: 11px;
      font-weight: 600;
      color: #0D7377;
      letter-spacing: 0.06em;
    }

    .chanio-chat-close {
      background: none;
      border: none;
      color: #3a5a70;
      cursor: pointer;
      font-size: 14px;
      line-height: 1;
      padding: 2px 4px;
      border-radius: 3px;
      transition: color 0.15s;
    }

    .chanio-chat-close:hover {
      color: #6b8fa8;
    }

    .chanio-chat-messages {
      flex: 1;
      overflow-y: auto;
      padding: 10px 14px;
      display: flex;
      flex-direction: column;
      gap: 8px;
      min-height: 0;
    }

    .chanio-chat-messages::-webkit-scrollbar {
      width: 4px;
    }

    .chanio-chat-messages::-webkit-scrollbar-track {
      background: #0A1420;
    }

    .chanio-chat-messages::-webkit-scrollbar-thumb {
      background: #1a3040;
      border-radius: 2px;
    }

    .chanio-msg {
      font-size: 12px;
      line-height: 1.5;
      max-width: 85%;
      padding: 6px 10px;
      border-radius: 6px;
      word-break: break-word;
    }

    .chanio-msg.user {
      align-self: flex-end;
      background: #0D7377;
      color: #0A1420;
    }

    .chanio-msg.assistant {
      align-self: flex-start;
      background: #0d2030;
      color: #a8c4d4;
    }

    .chanio-msg.system {
      align-self: center;
      color: #3a5a70;
      font-size: 11px;
      background: none;
      padding: 2px 0;
    }

    .chanio-msg.error {
      align-self: flex-start;
      background: #1a0d0d;
      color: #e05050;
      font-size: 11px;
    }

    .chanio-chat-input-row {
      display: flex;
      padding: 8px 12px;
      gap: 6px;
      border-top: 1px solid #1a3040;
      align-items: center;
      flex-shrink: 0;
    }

    .chanio-chat-input {
      flex: 1;
      background: #0d2030;
      border: 1px solid #1a3040;
      border-radius: 4px;
      color: #c8dde8;
      font-size: 12px;
      padding: 6px 10px;
      outline: none;
      transition: border-color 0.15s;
      min-width: 0;
    }

    .chanio-chat-input:focus {
      border-color: #0D7377;
    }

    .chanio-chat-input::placeholder {
      color: #3a5a70;
    }

    .chanio-chat-send {
      background: #0D7377;
      border: none;
      border-radius: 4px;
      color: #0A1420;
      font-size: 11px;
      font-weight: 600;
      padding: 6px 12px;
      cursor: pointer;
      flex-shrink: 0;
      transition: background 0.15s;
    }

    .chanio-chat-send:hover {
      background: #0f8a8f;
    }

    .chanio-chat-send:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    /* Narrow-window adjustments */
    @media (max-width: 480px) {
      .chanio-legal { display: none; }
      .chanio-story { display: none; }
    }
  `;
  shadow.appendChild(style);

  // ── Bar HTML ─────────────────────────────────────────────────────────────────
  const bar = document.createElement("div");
  bar.id = "chanio-bar";
  bar.innerHTML = `
    <a class="chanio-wordmark" href="https://chanio.com" target="_blank" rel="noopener" title="chanio.com">chanio</a>
    <div class="chanio-divider"></div>

    <button class="chanio-btn chanio-mic-btn" id="chanio-mic-btn" title="Voice input">
      <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <rect x="5" y="1" width="6" height="8" rx="3"/>
        <path d="M2 8a6 6 0 0012 0"/>
        <line x1="8" y1="14" x2="8" y2="11"/>
        <line x1="5" y1="14" x2="11" y2="14"/>
      </svg>
    </button>

    <span class="chanio-story" id="chanio-story">${STORIES[0]}</span>

    <button class="chanio-btn chanio-surf-btn" id="chanio-surf-btn" title="Surf a page you haven't seen">
      Surf
      <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <line x1="3" y1="8" x2="13" y2="8"/>
        <polyline points="9,4 13,8 9,12"/>
      </svg>
    </button>

    <button class="chanio-btn" id="chanio-save-btn" title="Save this page (Cmd+Shift+S)">
      <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M13 11v2a1 1 0 01-1 1H4a1 1 0 01-1-1v-2"/>
        <line x1="8" y1="2" x2="8" y2="10"/>
        <polyline points="5,7 8,10 11,7"/>
      </svg>
    </button>

    <button class="chanio-btn" id="chanio-chat-btn" title="Ask Sage (Cmd+Shift+C)">
      <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M14 10a2 2 0 01-2 2H5l-3 2V4a2 2 0 012-2h8a2 2 0 012 2v6z"/>
      </svg>
    </button>

    <div class="chanio-divider"></div>
    <span class="chanio-legal">© 2026 chanio · chanio.com</span>

    <div class="chanio-save-flash" id="chanio-save-flash"></div>
  `;
  shadow.appendChild(bar);

  // ── Chat panel HTML ───────────────────────────────────────────────────────────
  const chatPanel = document.createElement("div");
  chatPanel.id = "chanio-chat";
  chatPanel.innerHTML = `
    <div class="chanio-chat-header">
      <span class="chanio-chat-title">Sage — chanio</span>
      <button class="chanio-chat-close" id="chanio-chat-close" title="Close">&#x2715;</button>
    </div>
    <div class="chanio-chat-messages" id="chanio-chat-messages">
      <div class="chanio-msg system">Ask about this page, or anything on your mind.</div>
    </div>
    <div class="chanio-chat-input-row">
      <input class="chanio-chat-input" id="chanio-chat-input" placeholder="Ask Sage..." type="text" autocomplete="off" />
      <button class="chanio-chat-send" id="chanio-chat-send">Send</button>
    </div>
  `;
  shadow.appendChild(chatPanel);

  // ── Story rotation ────────────────────────────────────────────────────────────
  setInterval(() => {
    const el = shadow.getElementById("chanio-story");
    if (!el) return;
    el.classList.add("fade");
    setTimeout(() => {
      storyIndex = (storyIndex + 1) % STORIES.length;
      el.textContent = STORIES[storyIndex];
      el.classList.remove("fade");
    }, 400);
  }, 8000);

  // ── Save flash ────────────────────────────────────────────────────────────────
  function showSaveFlash(label) {
    const flash = shadow.getElementById("chanio-save-flash");
    if (!flash) return;
    flash.textContent = "Saved to " + (label || "chanio");
    flash.classList.add("visible");
    setTimeout(() => flash.classList.remove("visible"), 2200);
  }

  // ── Save button ───────────────────────────────────────────────────────────────
  shadow.getElementById("chanio-save-btn").addEventListener("click", () => {
    chrome.runtime.sendMessage(
      { type: "SAVE_PAGE", url: window.location.href, title: document.title },
      (result) => {
        if (chrome.runtime.lastError) return;
        if (result && result.success) showSaveFlash(result.channel);
      }
    );
  });

  // ── Surf button ───────────────────────────────────────────────────────────────
  shadow.getElementById("chanio-surf-btn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "GET_SURF_URL" }, (result) => {
      if (chrome.runtime.lastError) return;
      if (result && result.url) window.open(result.url, "_blank", "noopener");
    });
  });

  // ── Chat toggle ───────────────────────────────────────────────────────────────
  function openChat() {
    chatOpen = true;
    shadow.getElementById("chanio-chat").classList.add("open");
    // Expand host to show panel
    host.style.height = "364px"; // 44px bar + 320px panel
    setTimeout(() => shadow.getElementById("chanio-chat-input").focus(), 250);
  }

  function closeChat() {
    chatOpen = false;
    shadow.getElementById("chanio-chat").classList.remove("open");
    host.style.height = "44px";
  }

  shadow.getElementById("chanio-chat-btn").addEventListener("click", () => {
    chatOpen ? closeChat() : openChat();
  });

  shadow.getElementById("chanio-chat-close").addEventListener("click", closeChat);

  // ── Voice / Mic button ────────────────────────────────────────────────────────
  const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;

  shadow.getElementById("chanio-mic-btn").addEventListener("click", () => {
    if (!SpeechRecognitionAPI) {
      const story = shadow.getElementById("chanio-story");
      const prev = story.textContent;
      story.textContent = "Voice not supported in this browser.";
      setTimeout(() => { story.textContent = prev; }, 2200);
      return;
    }

    if (isRecording && recognition) {
      recognition.stop();
      return;
    }

    // Open chat if not open so the transcript appears
    if (!chatOpen) openChat();

    recognition = new SpeechRecognitionAPI();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    const micBtn = shadow.getElementById("chanio-mic-btn");
    const chatInput = shadow.getElementById("chanio-chat-input");

    recognition.onstart = () => {
      isRecording = true;
      micBtn.classList.add("recording");
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      chatInput.value = transcript;
      chatInput.focus();
    };

    recognition.onerror = () => {
      isRecording = false;
      micBtn.classList.remove("recording");
    };

    recognition.onend = () => {
      isRecording = false;
      micBtn.classList.remove("recording");
      recognition = null;
    };

    recognition.start();
  });

  // ── Chat send ─────────────────────────────────────────────────────────────────
  function appendMessage(role, text) {
    const messages = shadow.getElementById("chanio-chat-messages");
    const el = document.createElement("div");
    el.className = "chanio-msg " + role;
    el.textContent = text;
    messages.appendChild(el);
    messages.scrollTop = messages.scrollHeight;
    return el;
  }

  async function sendChat() {
    const input = shadow.getElementById("chanio-chat-input");
    const sendBtn = shadow.getElementById("chanio-chat-send");
    const text = input.value.trim();
    if (!text) return;

    input.value = "";
    sendBtn.disabled = true;

    appendMessage("user", text);
    chatHistory.push({ role: "user", content: text });

    const thinking = appendMessage("assistant", "...");

    chrome.runtime.sendMessage(
      { type: "CHAT", message: text, history: chatHistory.slice(-10) },
      (result) => {
        if (chrome.runtime.lastError) {
          thinking.className = "chanio-msg error";
          thinking.textContent = "Extension error. Try reloading the page.";
          sendBtn.disabled = false;
          return;
        }

        if (result && result.success && result.data) {
          const reply = result.data.answer || result.data.reply || result.data.message || result.data.content || "I could not generate a response.";
          thinking.textContent = reply;
          chatHistory.push({ role: "assistant", content: reply });
        } else {
          thinking.className = "chanio-msg error";
          thinking.textContent = "Sage is unavailable. Check your connection.";
        }

        sendBtn.disabled = false;
        const messages = shadow.getElementById("chanio-chat-messages");
        messages.scrollTop = messages.scrollHeight;
      }
    );
  }

  shadow.getElementById("chanio-chat-send").addEventListener("click", sendChat);

  shadow.getElementById("chanio-chat-input").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendChat();
    }
    if (e.key === "Escape") closeChat();
  });

  // ── Listen for messages from background (keyboard shortcuts) ─────────────────
  chrome.runtime.onMessage.addListener((message) => {
    if (!message || !message.type) return;

    if (message.type === "SHOW_SAVE_CONFIRMATION") {
      if (message.success) showSaveFlash(message.channel || "chanio");
    }

    if (message.type === "TOGGLE_CHAT") {
      chatOpen ? closeChat() : openChat();
    }
  });

  // ── Body padding so bar never covers content ──────────────────────────────────
  function adjustBodyPadding() {
    const body = document.body;
    if (!body) return;
    const current = parseInt(window.getComputedStyle(body).paddingBottom, 10) || 0;
    if (current < 44) body.style.paddingBottom = "44px";
  }

  if (document.readyState === "complete") {
    adjustBodyPadding();
  } else {
    window.addEventListener("load", adjustBodyPadding, { once: true });
  }

})();
