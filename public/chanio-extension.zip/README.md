# chanio Chrome Extension

Making the web surfable and memorable.

## Install (unpacked, developer mode)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (toggle, top-right corner)
3. Click **Load unpacked**
4. Select this folder: `/Users/blaine/Documents/chanio-extension`
5. The chanio bar appears at the bottom of every page immediately

## Features

| Feature | How to use |
|---|---|
| **Passive catalog** | Every page you visit is logged automatically (last 500) |
| **Save page** | Click the download icon in the bar, or press **Cmd+Shift+S** (Mac) / **Ctrl+Shift+S** (Win) |
| **Surf** | Click the **Surf** button — opens a curated page you haven't visited yet |
| **Chat with Sage** | Click the chat bubble icon — slide-up panel with conversation history |
| **Voice input** | Click the mic icon — speak your question, transcript drops into chat input |
| **Open chat** | Press **Cmd+Shift+C** (Mac) / **Ctrl+Shift+C** (Win) from any page |
| **Popup stats** | Click the chanio icon in the Chrome toolbar — see saved/visited counts and recent saves |

## File structure

```
chanio-extension/
  manifest.json       MV3 manifest
  background.js       Service worker: catalog, saves, badge, surf, chat proxy
  content.js          Injects the bar and chat panel via Shadow DOM
  content.css         Minimal placeholder (all bar styles live in Shadow DOM)
  popup.html          Extension toolbar popup
  popup.js            Popup logic
  icons/
    icon16.png
    icon48.png
    icon128.png
  README.md
```

## Permissions

- `activeTab` — read current tab URL and title
- `storage` — local-only storage of catalog and saves (nothing leaves the browser)
- `tabs` — required for passive visit logging (`tabs.onUpdated`) and keyboard shortcut tab lookup

## Data storage

All data is in `chrome.storage.local`:

- `catalog` — rolling array of last 500 page visits `{url, title, domain, channel, timestamp}`
- `saves` — up to 1000 explicitly saved pages `{url, title, domain, channel, savedAt}`

Data persists across browser restarts. Nothing is sent to any server unless you use the chat feature.

## Chat endpoint

The chat panel sends messages through the background service worker to:

```
POST https://solvinghealth.com/api/chat
{ "message": "...", "channel": "chanio", "history": [...] }
```

If the endpoint is unavailable, an error message is shown in the chat panel.

## Troubleshooting

**Bar not appearing**
- Check `chrome://extensions` — chanio should show no errors
- Hard-reload the page (Cmd+Shift+R)
- Some pages block all extensions (`chrome://` URLs, Chrome Web Store) — this is expected

**Service worker not starting**
- Go to `chrome://extensions`, click the "service worker" link next to chanio
- Check the DevTools console for errors
- Click the reload icon on the chanio card

**Keyboard shortcuts not working**
- Go to `chrome://extensions/shortcuts`
- Verify Cmd+Shift+S and Cmd+Shift+C are assigned to chanio
- Chrome sometimes requires you to set shortcuts manually in that page

**Permission denied errors**
- The extension uses `host_permissions: ["<all_urls>"]` — Chrome may show a permission prompt on first install
- Click "Allow" to enable the bar on all sites

**Chat shows "Sage is unavailable"**
- The `solvinghealth.com/api/chat` endpoint must be live and reachable
- Check your internet connection
- Open DevTools on the background service worker to see the raw fetch error

## Development notes

- Shadow DOM prevents host-page styles from affecting the bar
- `body.paddingBottom = 44px` is set so content is never hidden behind the bar
- The extension skips `chrome://`, `chrome-extension://`, and `about:` URLs
- Surf picks from 30 curated URLs, preferring ones not in your recent catalog
- Chat history is kept in memory per page — it resets on navigation
