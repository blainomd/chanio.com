// chanio popup.js

function formatAge(ts) {
  const diff = Date.now() - ts;
  if (diff < 60000) return "just now";
  if (diff < 3600000) return Math.floor(diff / 60000) + "m ago";
  if (diff < 86400000) return Math.floor(diff / 3600000) + "h ago";
  return new Date(ts).toLocaleDateString();
}

function esc(str) {
  return (str || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function trunc(str, max) {
  if (!str) return "";
  return str.length > max ? str.slice(0, max) + "..." : str;
}

// Load stats from background
chrome.runtime.sendMessage({ type: "GET_STATS" }, (data) => {
  if (chrome.runtime.lastError || !data) return;

  document.getElementById("saves-count").textContent = data.savesCount || 0;
  document.getElementById("catalog-count").textContent = data.catalogCount || 0;

  const container = document.getElementById("recent-saves");

  if (!data.recentSaves || data.recentSaves.length === 0) {
    container.innerHTML = '<div class="empty-state">No saves yet. Click the bar below or press Cmd+Shift+S.</div>';
    return;
  }

  container.innerHTML = data.recentSaves.map(save => `
    <div class="save-item">
      <a class="save-title" href="${esc(save.url)}" target="_blank" rel="noopener" title="${esc(save.url)}">${esc(trunc(save.title, 50))}</a>
      <div class="save-meta">
        <span class="save-channel">${esc(save.channel || "web")}</span>
        <span>${esc(trunc(save.domain, 28))}</span>
        <span>${formatAge(save.savedAt)}</span>
      </div>
    </div>
  `).join("");
});

// Surf button — open a curated URL in a new tab
document.getElementById("surf-btn").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "GET_SURF_URL" }, (result) => {
    if (chrome.runtime.lastError) return;
    if (result && result.url) {
      chrome.tabs.create({ url: result.url });
      window.close();
    }
  });
});

// Save current page
document.getElementById("save-current-btn").addEventListener("click", async () => {
  const btn = document.getElementById("save-current-btn");
  btn.textContent = "Saving...";
  btn.disabled = true;

  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab) {
      btn.textContent = "No active tab";
      btn.disabled = false;
      return;
    }

    chrome.runtime.sendMessage(
      { type: "SAVE_PAGE", url: tab.url, title: tab.title },
      (result) => {
        if (chrome.runtime.lastError) {
          btn.textContent = "Error saving";
          btn.disabled = false;
          return;
        }
        if (result && result.success) {
          btn.textContent = "Saved to " + result.channel;
          btn.style.background = "#0D7377";
          btn.style.borderColor = "#0D7377";
          setTimeout(() => window.close(), 900);
        } else {
          btn.textContent = (result && result.reason) ? result.reason : "Cannot save this page";
          btn.disabled = false;
        }
      }
    );
  } catch (err) {
    btn.textContent = "Error";
    btn.disabled = false;
  }
});
