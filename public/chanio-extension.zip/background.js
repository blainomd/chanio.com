// chanio background service worker
// Handles: passive catalog logging, save events, badge updates, surf picks, chat proxy

const MAX_CATALOG_ENTRIES = 500;
const MAX_SAVES = 1000;
const CHAT_ENDPOINT = "https://solvinghealth.com/api/chat";

// First-install welcome — opens chanio.com/welcome on install
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: "https://chanio.com/welcome" });
    chrome.action.setBadgeText({ text: "NEW" });
    chrome.action.setBadgeBackgroundColor({ color: "#0D7377" });
    setTimeout(() => chrome.action.setBadgeText({ text: "" }), 60000);
  } else if (details.reason === "update") {
    const previousVersion = details.previousVersion;
    const currentVersion = chrome.runtime.getManifest().version;
    if (previousVersion !== currentVersion) {
      chrome.action.setBadgeText({ text: "•" });
      chrome.action.setBadgeBackgroundColor({ color: "#0D7377" });
      setTimeout(() => chrome.action.setBadgeText({ text: "" }), 30000);
    }
  }
});

// Curated surf URLs — 30 entries covering health, productivity, and independent web
const ECOSYSTEM_URLS = [
  { url: "https://www.are.na", title: "Are.na" },
  { url: "https://solar.lowtechmagazine.com", title: "Low-Tech Magazine" },
  { url: "https://pubmed.ncbi.nlm.nih.gov", title: "PubMed" },
  { url: "https://www.mayoclinic.org", title: "Mayo Clinic" },
  { url: "https://co-op.care", title: "co-op.care" },
  { url: "https://surgeonvalue.com", title: "SurgeonValue" },
  { url: "https://solvinghealth.com", title: "SolvingHealth" },
  { url: "https://www.marginalia.nu", title: "Marginalia" },
  { url: "https://wiby.me", title: "Wiby" },
  { url: "https://100r.co", title: "Hundred Rabbits" },
  { url: "https://interconnected.org/home", title: "Matt Webb" },
  { url: "https://kottke.org", title: "Kottke.org" },
  { url: "https://maggieappleton.com", title: "Maggie Appleton" },
  { url: "https://www.robinsloan.com", title: "Robin Sloan" },
  { url: "https://thecreativeindependent.com", title: "The Creative Independent" },
  { url: "https://psyche.co", title: "Psyche" },
  { url: "https://nautil.us", title: "Nautilus" },
  { url: "https://www.brainpickings.org", title: "The Marginalian" },
  { url: "https://longform.org", title: "Longform" },
  { url: "https://www.ribbonfarm.com", title: "Ribbonfarm" },
  { url: "https://fs.blog", title: "Farnam Street" },
  { url: "https://thereader.mitpress.mit.edu", title: "MIT Press Reader" },
  { url: "https://aeon.co", title: "Aeon" },
  { url: "https://www.sciencenews.org", title: "Science News" },
  { url: "https://e360.yale.edu", title: "Yale E360" },
  { url: "https://www.technologyreview.com", title: "MIT Tech Review" },
  { url: "https://restofworld.org", title: "Rest of World" },
  { url: "https://www.logic-mag.io", title: "Logic Magazine" },
  { url: "https://hsaletter.com", title: "HSA Letter" },
  { url: "https://www.swyx.io", title: "swyx" }
];

// Detect channel name from domain
function detectChannel(url) {
  try {
    const domain = new URL(url).hostname.replace("www.", "");
    const parts = domain.split(".");
    return parts.length >= 2 ? parts[parts.length - 2] : domain;
  } catch {
    return "web";
  }
}

// Log page to passive catalog
async function logPageVisit(url, title) {
  if (!url || url.startsWith("chrome://") || url.startsWith("chrome-extension://") || url.startsWith("about:")) {
    return;
  }

  const entry = {
    url,
    title: title || url,
    domain: new URL(url).hostname,
    channel: detectChannel(url),
    timestamp: Date.now()
  };

  const data = await chrome.storage.local.get("catalog");
  const catalog = data.catalog || [];
  catalog.unshift(entry);

  if (catalog.length > MAX_CATALOG_ENTRIES) {
    catalog.splice(MAX_CATALOG_ENTRIES);
  }

  await chrome.storage.local.set({ catalog });
  updateBadge();
}

// Explicitly save a page
async function savePage(url, title) {
  if (!url || url.startsWith("chrome://") || url.startsWith("chrome-extension://")) {
    return { success: false, reason: "Cannot save this page" };
  }

  const channel = detectChannel(url);
  const save = {
    url,
    title: title || url,
    domain: new URL(url).hostname,
    channel,
    savedAt: Date.now()
  };

  const data = await chrome.storage.local.get("saves");
  const saves = data.saves || [];

  const existing = saves.findIndex(s => s.url === url);
  if (existing >= 0) {
    saves[existing] = save;
  } else {
    saves.unshift(save);
    if (saves.length > MAX_SAVES) saves.splice(MAX_SAVES);
  }

  await chrome.storage.local.set({ saves });
  updateBadge();
  return { success: true, channel };
}

// Update toolbar badge with saves count
async function updateBadge() {
  const data = await chrome.storage.local.get("saves");
  const count = (data.saves || []).length;
  if (count > 0) {
    chrome.action.setBadgeText({ text: count > 99 ? "99+" : String(count) });
    chrome.action.setBadgeBackgroundColor({ color: "#0D7377" });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}

// Pick a surf URL, preferring unvisited
async function pickSurfUrl() {
  const data = await chrome.storage.local.get("catalog");
  const catalog = data.catalog || [];
  const visitedUrls = new Set(catalog.map(e => e.url));

  const unvisited = ECOSYSTEM_URLS.filter(e => !visitedUrls.has(e.url));
  const pool = unvisited.length > 0 ? unvisited : ECOSYSTEM_URLS;
  return pool[Math.floor(Math.random() * pool.length)];
}

// Proxy chat request to Sage API
async function sendChat(message, history) {
  const response = await fetch(CHAT_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message,
      channel: "chanio",
      history: history || []
    })
  });

  if (!response.ok) {
    throw new Error("API returned " + response.status);
  }

  return response.json();
}

// Passive page visit logging via tabs.onUpdated
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && tab.title) {
    logPageVisit(tab.url, tab.title);
  }
});

// Message handler — all content/popup messages route through here
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === "SAVE_PAGE") {
    savePage(message.url, message.title)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, reason: err.message }));
    return true;
  }

  if (message.type === "GET_SURF_URL") {
    pickSurfUrl()
      .then(result => sendResponse(result))
      .catch(() => sendResponse(ECOSYSTEM_URLS[0]));
    return true;
  }

  if (message.type === "CHAT") {
    sendChat(message.message, message.history)
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, reason: err.message }));
    return true;
  }

  if (message.type === "GET_STATS") {
    chrome.storage.local.get(["saves", "catalog"]).then(data => {
      sendResponse({
        savesCount: (data.saves || []).length,
        catalogCount: (data.catalog || []).length,
        recentSaves: (data.saves || []).slice(0, 5)
      });
    });
    return true;
  }
});

// Keyboard shortcut handler
chrome.commands.onCommand.addListener(async (command) => {
  if (command === "save_page") {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab && tab.url && tab.id) {
      const result = await savePage(tab.url, tab.title);
      // Show confirmation flash in the content script
      chrome.tabs.sendMessage(tab.id, {
        type: "SHOW_SAVE_CONFIRMATION",
        channel: result.channel,
        success: result.success
      }).catch(() => {});
    }
  }

  if (command === "open_chanio") {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, { type: "TOGGLE_CHAT" }).catch(() => {});
    }
  }
});

// Initialize badge on startup and install
chrome.runtime.onStartup.addListener(updateBadge);
chrome.runtime.onInstalled.addListener(updateBadge);
